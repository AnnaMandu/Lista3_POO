﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exe2
{
    internal class Quadrado
    {
        private int a;
        private int area;

        public Quadrado()
        {
            this.a = 0;
        }

        public Quadrado(int a)
        {
            this.a = a;
        }

        public void setA(int a)
        {
            this.a = a;
        }

        public int getA()
        {
            return this.a;
        }

        public int getArea()
        {
            return area;
        }

        public void calcularArea()
        {
            area = this.a * this.a;
        }
    }
}
