﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exe1
{
    internal class Retangulo
    {
        private double a;
        private double b;
        private double area;

        public Retangulo()
        {
            this.a = 0;
            this.b = 0;
        }

        public Retangulo(double a, double b)
        {
            this.a = a;
            this.b = b;
        }

        public void setA(double a)
        {
            this.a = a;
        }

        public void setB(double b)
        {
            this.b = b;
        }

        public double getA()
        {
            return this.a;
        }

        public double getB()
        {
            return this.b;
        }

        public double getArea()
        {
            return area;
        }

        public void calcularArea()
        {
            area = this.a * this.b;
        }
    }
}
