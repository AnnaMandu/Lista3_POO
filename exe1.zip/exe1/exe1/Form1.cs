﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcular(object sender, EventArgs e)
        {
            Retangulo retangulo;
            retangulo = new Retangulo();
            retangulo.setA(int.Parse(txtA.Text));
            retangulo.setB(int.Parse(txtB.Text));
            retangulo.calcularArea();
            lblResultado.Text = retangulo.getArea().ToString();
        }
    }
}
