﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Converter(object sender, EventArgs e)
        {
            Dinheiro dinheiro;
            dinheiro = new Dinheiro();
            dinheiro.setDolar(double.Parse(txtDolar.Text));
            dinheiro.setCota(double.Parse(txtCotacao.Text));
            dinheiro.converter();
            lblResultado.Text = dinheiro.getReal().ToString();
        }
    }
}
