﻿namespace exe4
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bntCalcular = new System.Windows.Forms.Button();
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblArea = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bntCalcular
            // 
            this.bntCalcular.Location = new System.Drawing.Point(282, 287);
            this.bntCalcular.Name = "bntCalcular";
            this.bntCalcular.Size = new System.Drawing.Size(162, 59);
            this.bntCalcular.TabIndex = 0;
            this.bntCalcular.Text = "Calcular";
            this.bntCalcular.UseVisualStyleBackColor = true;
            this.bntCalcular.Click += new System.EventHandler(this.Calcular);
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(146, 80);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(41, 16);
            this.lblA.TabIndex = 1;
            this.lblA.Text = "Altura";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(147, 128);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(39, 16);
            this.lblB.TabIndex = 2;
            this.lblB.Text = "Base";
            // 
            // lblArea
            // 
            this.lblArea.AutoSize = true;
            this.lblArea.Location = new System.Drawing.Point(218, 206);
            this.lblArea.Name = "lblArea";
            this.lblArea.Size = new System.Drawing.Size(50, 16);
            this.lblArea.TabIndex = 3;
            this.lblArea.Text = "Área é:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(329, 207);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(14, 16);
            this.lblResultado.TabIndex = 4;
            this.lblResultado.Text = "0";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(266, 72);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(163, 22);
            this.txtA.TabIndex = 5;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(266, 124);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(162, 22);
            this.txtB.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblArea);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.bntCalcular);
            this.Name = "Form1";
            this.Text = "Triangulo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bntCalcular;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblArea;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
    }
}

