﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calcular(object sender, EventArgs e)
        {
            Triangulo triangulo;
            triangulo = new Triangulo();
            triangulo.setAlt(int.Parse(txtA.Text));
            triangulo.setBas(int.Parse(txtB.Text));
            triangulo.calcularArea();
            lblResultado.Text = triangulo.getArea().ToString();
        }
    }
}
