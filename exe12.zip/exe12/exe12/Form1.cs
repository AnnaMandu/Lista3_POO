﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Classificar(object sender, EventArgs e)
        {
            Triangulo triangulo;
            triangulo = new Triangulo(
                int.Parse(txtL1.Text),
                int.Parse(txtL2.Text),
                int.Parse(txtL3.Text));
            triangulo.compararTriangulo();


            if (triangulo.getTipo() == 0)
            {
                lblClassificar.Text = "Equilatero";
                
            }
            else
                if (triangulo.getTipo() == 1)
            {
                lblClassificar.Text = "Isosceles";
            }
            else
                if (triangulo.getTipo() == 2)
            {
                lblClassificar.Text = "Escaleno";
            }
            else
                if(triangulo.getTipo() == 3)
            {
                lblClassificar.Text = "Não forma triangulo";
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
