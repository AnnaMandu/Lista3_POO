﻿namespace exe12
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClassificar = new System.Windows.Forms.Button();
            this.lblL1 = new System.Windows.Forms.Label();
            this.lblL2 = new System.Windows.Forms.Label();
            this.lblL3 = new System.Windows.Forms.Label();
            this.lblClassificar = new System.Windows.Forms.Label();
            this.txtL1 = new System.Windows.Forms.TextBox();
            this.txtL2 = new System.Windows.Forms.TextBox();
            this.txtL3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnClassificar
            // 
            this.btnClassificar.Location = new System.Drawing.Point(297, 259);
            this.btnClassificar.Name = "btnClassificar";
            this.btnClassificar.Size = new System.Drawing.Size(156, 51);
            this.btnClassificar.TabIndex = 0;
            this.btnClassificar.Text = "Classificar";
            this.btnClassificar.UseVisualStyleBackColor = true;
            this.btnClassificar.Click += new System.EventHandler(this.Classificar);
            // 
            // lblL1
            // 
            this.lblL1.AutoSize = true;
            this.lblL1.Location = new System.Drawing.Point(178, 69);
            this.lblL1.Name = "lblL1";
            this.lblL1.Size = new System.Drawing.Size(48, 16);
            this.lblL1.TabIndex = 1;
            this.lblL1.Text = "Lado 1";
            this.lblL1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblL2
            // 
            this.lblL2.AutoSize = true;
            this.lblL2.Location = new System.Drawing.Point(178, 111);
            this.lblL2.Name = "lblL2";
            this.lblL2.Size = new System.Drawing.Size(48, 16);
            this.lblL2.TabIndex = 2;
            this.lblL2.Text = "Lado 2";
            // 
            // lblL3
            // 
            this.lblL3.AutoSize = true;
            this.lblL3.Location = new System.Drawing.Point(178, 163);
            this.lblL3.Name = "lblL3";
            this.lblL3.Size = new System.Drawing.Size(48, 16);
            this.lblL3.TabIndex = 3;
            this.lblL3.Text = "Lado 3";
            // 
            // lblClassificar
            // 
            this.lblClassificar.AutoSize = true;
            this.lblClassificar.Location = new System.Drawing.Point(358, 219);
            this.lblClassificar.Name = "lblClassificar";
            this.lblClassificar.Size = new System.Drawing.Size(31, 16);
            this.lblClassificar.TabIndex = 4;
            this.lblClassificar.Text = "------";
            // 
            // txtL1
            // 
            this.txtL1.Location = new System.Drawing.Point(271, 66);
            this.txtL1.Name = "txtL1";
            this.txtL1.Size = new System.Drawing.Size(201, 22);
            this.txtL1.TabIndex = 5;
            // 
            // txtL2
            // 
            this.txtL2.Location = new System.Drawing.Point(274, 108);
            this.txtL2.Name = "txtL2";
            this.txtL2.Size = new System.Drawing.Size(197, 22);
            this.txtL2.TabIndex = 6;
            // 
            // txtL3
            // 
            this.txtL3.Location = new System.Drawing.Point(274, 160);
            this.txtL3.Name = "txtL3";
            this.txtL3.Size = new System.Drawing.Size(202, 22);
            this.txtL3.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtL3);
            this.Controls.Add(this.txtL2);
            this.Controls.Add(this.txtL1);
            this.Controls.Add(this.lblClassificar);
            this.Controls.Add(this.lblL3);
            this.Controls.Add(this.lblL2);
            this.Controls.Add(this.lblL1);
            this.Controls.Add(this.btnClassificar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClassificar;
        private System.Windows.Forms.Label lblL1;
        private System.Windows.Forms.Label lblL2;
        private System.Windows.Forms.Label lblL3;
        private System.Windows.Forms.Label lblClassificar;
        private System.Windows.Forms.TextBox txtL1;
        private System.Windows.Forms.TextBox txtL2;
        private System.Windows.Forms.TextBox txtL3;
    }
}

