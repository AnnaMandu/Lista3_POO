﻿namespace exe5
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMilha = new System.Windows.Forms.Label();
            this.lblAss = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnConverter = new System.Windows.Forms.Button();
            this.txtMilha = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblMilha
            // 
            this.lblMilha.AutoSize = true;
            this.lblMilha.Location = new System.Drawing.Point(211, 82);
            this.lblMilha.Name = "lblMilha";
            this.lblMilha.Size = new System.Drawing.Size(39, 16);
            this.lblMilha.TabIndex = 0;
            this.lblMilha.Text = "Milha";
            // 
            // lblAss
            // 
            this.lblAss.AutoSize = true;
            this.lblAss.Location = new System.Drawing.Point(196, 169);
            this.lblAss.Name = "lblAss";
            this.lblAss.Size = new System.Drawing.Size(185, 16);
            this.lblAss.TabIndex = 1;
            this.lblAss.Text = "O resultado em quilometros é:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(425, 169);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(14, 16);
            this.lblResultado.TabIndex = 2;
            this.lblResultado.Text = "0";
            // 
            // btnConverter
            // 
            this.btnConverter.Location = new System.Drawing.Point(277, 248);
            this.btnConverter.Name = "btnConverter";
            this.btnConverter.Size = new System.Drawing.Size(202, 78);
            this.btnConverter.TabIndex = 3;
            this.btnConverter.Text = "Converter";
            this.btnConverter.UseVisualStyleBackColor = true;
            this.btnConverter.Click += new System.EventHandler(this.Converte);
            // 
            // txtMilha
            // 
            this.txtMilha.Location = new System.Drawing.Point(310, 82);
            this.txtMilha.Name = "txtMilha";
            this.txtMilha.Size = new System.Drawing.Size(178, 22);
            this.txtMilha.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtMilha);
            this.Controls.Add(this.btnConverter);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblAss);
            this.Controls.Add(this.lblMilha);
            this.Name = "Form1";
            this.Text = "Conversão";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMilha;
        private System.Windows.Forms.Label lblAss;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnConverter;
        private System.Windows.Forms.TextBox txtMilha;
    }
}

