﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Converte(object sender, EventArgs e)
        {
            Milha milha;
            milha = new Milha();
            milha.setMilha(int.Parse(txtMilha.Text));
            milha.converter();
            lblResultado.Text = milha.getResultado().ToString();
        }
    }
}
