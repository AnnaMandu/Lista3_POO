﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exe3
{
    internal class Quadrado
    {
        private int d;
        private int area;

        public Quadrado()
        {
            this.d = 0;
        }

        public Quadrado(int d)
        {
            this.d = d;
        }
        public void setD(int d)
        {
            this.d = d;
        }

        public int getD()
        {
            return this.d;
        }

        public int getArea()
        {
            return area;
        }

        public void calcularArea()
        {
            area = (this.d * this.d) / 2;
        }
    
}
}
