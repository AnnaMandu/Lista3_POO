﻿namespace exe8
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblP = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.lblAss = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnComparar = new System.Windows.Forms.Button();
            this.txtP = new System.Windows.Forms.TextBox();
            this.txtS = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblP
            // 
            this.lblP.AutoSize = true;
            this.lblP.Location = new System.Drawing.Point(169, 80);
            this.lblP.Name = "lblP";
            this.lblP.Size = new System.Drawing.Size(105, 16);
            this.lblP.TabIndex = 0;
            this.lblP.Text = "Primeiro numero";
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.Location = new System.Drawing.Point(180, 145);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(110, 16);
            this.lblS.TabIndex = 1;
            this.lblS.Text = "Segundo numero";
            // 
            // lblAss
            // 
            this.lblAss.AutoSize = true;
            this.lblAss.Location = new System.Drawing.Point(231, 232);
            this.lblAss.Name = "lblAss";
            this.lblAss.Size = new System.Drawing.Size(101, 16);
            this.lblAss.TabIndex = 2;
            this.lblAss.Text = "O maior valor é:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(379, 232);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(14, 16);
            this.lblResultado.TabIndex = 3;
            this.lblResultado.Text = "0";
            // 
            // btnComparar
            // 
            this.btnComparar.Location = new System.Drawing.Point(304, 318);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(157, 59);
            this.btnComparar.TabIndex = 4;
            this.btnComparar.Text = "Comparar";
            this.btnComparar.UseVisualStyleBackColor = true;
            this.btnComparar.Click += new System.EventHandler(this.Comparar);
            // 
            // txtP
            // 
            this.txtP.Location = new System.Drawing.Point(342, 77);
            this.txtP.Name = "txtP";
            this.txtP.Size = new System.Drawing.Size(153, 22);
            this.txtP.TabIndex = 5;
            // 
            // txtS
            // 
            this.txtS.Location = new System.Drawing.Point(342, 142);
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(153, 22);
            this.txtS.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtS);
            this.Controls.Add(this.txtP);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblAss);
            this.Controls.Add(this.lblS);
            this.Controls.Add(this.lblP);
            this.Name = "Form1";
            this.Text = "Maior valor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblP;
        private System.Windows.Forms.Label lblS;
        private System.Windows.Forms.Label lblAss;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.TextBox txtP;
        private System.Windows.Forms.TextBox txtS;
    }
}

