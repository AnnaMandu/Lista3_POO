﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Comparar(object sender, EventArgs e)
        {
            Numero numero;
            numero = new Numero();
            numero.setS(int.Parse(txtS.Text));  
            numero.setP(int.Parse(txtP.Text));
            numero.compararNumero();
            lblResultado.Text = numero.getMM().ToString();
        }
    }
}
