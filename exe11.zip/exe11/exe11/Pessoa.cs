﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exe11
{
    internal class Pessoa
    {
        private double alt;
        private double peso;
        private double tipo;
        private double r;

        public Pessoa()
        {
            this.alt = 0;
            this.peso = 0;
        }

        public Pessoa(int alt, int peso)
        {
            this.alt = alt;
            this.peso = peso;
        }

        public void setAlt(double alt)
        {
            this.alt = alt;
        }

        public void setPeso(double peso)
        {
            this.peso = peso;
        }

        public double getAlt()
        {
            return this.alt;
        }

        public double getPeso()
        {
            return this.peso;
        }

        public double getTipo()
        {
            return this.tipo;
        }

        public void calcularRelacao()
        {
            r = this.peso / (this.alt * this.alt);
        }

        public void definirPesoIdeal()
        {
            if (r < 20)
            {
                this.tipo = 0;
            }
            else
            {
                if (r >= 20 && r < 25)
                {
                    this.tipo = 1;
                }
                else
                {
                    this.tipo = 2;
                }
            }
        }
    }
}
