﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calcular(object sender, EventArgs e)
        {
            Pessoa peso;
            peso = new Pessoa();

            peso.setAlt(double.Parse(txtAlt.Text));
            peso.setPeso(double.Parse(txtPeso.Text));

            peso.calcularRelacao();
            peso.definirPesoIdeal();

            if (peso.getTipo() == 0)
            {
                lblResultado.Text = "Abaixo do peso";
                picMass.Image = exe11.Properties.Resources.abaixo_;
            }
            else
               if (peso.getTipo() == 1)
            {
                lblResultado.Text = "Peso ideal";
                picMass.Image = exe11.Properties.Resources.normal;
            }
            else
            {
                lblResultado.Text = "Acima do peso";
                picMass.Image = exe11.Properties.Resources.acima;
            }
        }
    }
}
