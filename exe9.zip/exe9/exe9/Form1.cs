﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exe9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Comparar(object sender, EventArgs e)
        {
            Numero numero;
            numero = new Numero();
            numero.setP(int.Parse(txtP.Text));
            numero.setS(int.Parse(txtS.Text));
            numero.compararNumero();

            if (numero.getC() == 0)
            {
                lblResultado.Text = numero.getP().ToString();
         
            }
            else
                if (numero.getC() == 1)
            {
                lblResultado.Text = "São iguais";
            }
            else
            {
                lblResultado.Text = numero.getS().ToString();
            }
        }
    }
}
