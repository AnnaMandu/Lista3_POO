﻿namespace exe9
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblP = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtP = new System.Windows.Forms.TextBox();
            this.txtS = new System.Windows.Forms.TextBox();
            this.btnComparar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblP
            // 
            this.lblP.AutoSize = true;
            this.lblP.Location = new System.Drawing.Point(198, 73);
            this.lblP.Name = "lblP";
            this.lblP.Size = new System.Drawing.Size(105, 16);
            this.lblP.TabIndex = 0;
            this.lblP.Text = "Primeiro numero";
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.Location = new System.Drawing.Point(198, 133);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(110, 16);
            this.lblS.TabIndex = 1;
            this.lblS.Text = "Segundo numero";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(390, 215);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(27, 16);
            this.lblResultado.TabIndex = 3;
            this.lblResultado.Text = "-----";
            // 
            // txtP
            // 
            this.txtP.Location = new System.Drawing.Point(333, 70);
            this.txtP.Name = "txtP";
            this.txtP.Size = new System.Drawing.Size(146, 22);
            this.txtP.TabIndex = 4;
            // 
            // txtS
            // 
            this.txtS.Location = new System.Drawing.Point(336, 130);
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(143, 22);
            this.txtS.TabIndex = 5;
            // 
            // btnComparar
            // 
            this.btnComparar.Location = new System.Drawing.Point(336, 281);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(124, 60);
            this.btnComparar.TabIndex = 6;
            this.btnComparar.Text = "Comparar";
            this.btnComparar.UseVisualStyleBackColor = true;
            this.btnComparar.Click += new System.EventHandler(this.Comparar);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.txtS);
            this.Controls.Add(this.txtP);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblS);
            this.Controls.Add(this.lblP);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblP;
        private System.Windows.Forms.Label lblS;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtP;
        private System.Windows.Forms.TextBox txtS;
        private System.Windows.Forms.Button btnComparar;
    }
}

